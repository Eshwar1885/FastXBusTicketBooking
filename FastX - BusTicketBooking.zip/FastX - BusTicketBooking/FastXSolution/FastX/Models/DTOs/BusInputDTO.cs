﻿namespace FastX.Models.DTOs
{
    public class BusInputDTO
    {
        public string? Origin { get; set; }
        public string? Destination { get; set; }
        public DateTime TravelDate { get; set; }


    }
}
