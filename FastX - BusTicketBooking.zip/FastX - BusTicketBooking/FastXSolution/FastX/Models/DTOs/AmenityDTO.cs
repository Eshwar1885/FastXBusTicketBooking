﻿namespace FastX.Models.DTOs

{
    public class AmenityDTO
    {
        public int AmenityId { get; set; }
        public string? Name { get; set; }
    }
}