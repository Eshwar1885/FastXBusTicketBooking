﻿namespace FastX.Models.DTOs
{
    public class BusDTOForOperator
    {
        public int BusId { get; set; }
        public string? BusName { get; set; }
        public int BusOperatorId { get; set; }
        public string? BusType { get; set; }
    }
}
