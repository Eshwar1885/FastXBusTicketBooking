﻿namespace FastX.Models.DTOs
{
    public class LoginUserInputDTO
    {
        public string Username { get; set; }
        public string Password { get; set; }
        //public string Token { get; set; }

    }
}
