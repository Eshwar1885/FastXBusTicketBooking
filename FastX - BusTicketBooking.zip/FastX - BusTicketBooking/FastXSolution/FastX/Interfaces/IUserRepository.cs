﻿//namespace FastX.Interfaces
//{
//    public interface IUserRepository<T> where T : class
//    {
//        Task<T> GetByIdAsync(object id);
//        Task DeleteAsync(object id);
//        Task SaveChangesAsync();
//    }
//}
