﻿//using FastX.Models;

//namespace FastX.Interfaces
//{
//    public interface IAdminService
//    {
//        //public Task<Admin> Delete(string name);
//        //public Task<Admin> GetAsync(string name);
//        Task DeleteUserAsync(string username);


//    }
//}
